function data_norm = normalize_per_sample(data)
% Per-sample normalization: zero mean, unit variance
%
% Input:
%   data: Cell array of CSI matrices [subcarriers x time_steps]
%
% Output:
%   data_norm: Normalized cell array (each sample: mean=0, std=1)

    data_norm = cell(size(data));
    for i = 1:length(data)
        sample = data{i};
        mu = mean(sample(:));
        sigma = std(sample(:));
        if sigma == 0, sigma = 1; end
        data_norm{i} = (sample - mu) / sigma;
    end
end
