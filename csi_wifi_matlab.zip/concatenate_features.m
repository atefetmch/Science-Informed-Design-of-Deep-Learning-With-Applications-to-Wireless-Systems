function data_concat = concatenate_features(data_time, data_freq)
% Concatenate time and frequency features with padding
%
% Stacks time and frequency features vertically, padding or truncating
% the frequency domain to match the time domain sequence length.
%
% Inputs:
%   data_time: Cell array of time-domain features [n_sub x n_time]
%   data_freq: Cell array of freq-domain features [n_sub x n_freq]
%
% Output:
%   data_concat: Cell array [(n_sub_time + n_sub_freq) x n_time]

    data_concat = cell(size(data_time));

    for i = 1:length(data_time)
        time_feat = data_time{i};  % [n_subcarriers x n_time]
        freq_feat = data_freq{i};  % [n_subcarriers x n_freq]

        [~, n_time] = size(time_feat);
        [n_sub_freq, n_freq] = size(freq_feat);

        % Match frequency sequence length to time sequence length
        if n_freq < n_time
            freq_feat_matched = [freq_feat, zeros(n_sub_freq, n_time - n_freq)];
        elseif n_freq > n_time
            freq_feat_matched = freq_feat(:, 1:n_time);
        else
            freq_feat_matched = freq_feat;
        end

        % Stack vertically: [time_features; freq_features]
        data_concat{i} = [time_feat; freq_feat_matched];

        if mod(i, 100) == 0
            fprintf('    Processed %d/%d\r', i, length(data_time));
        end
    end
    fprintf('\n');
end
