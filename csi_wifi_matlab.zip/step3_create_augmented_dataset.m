%% STEP 3: Create Augmented Dataset
% Applies augmentations to make the dataset more challenging.
%
% Input:  lstm_data_prepared.mat (from step2)
% Output: lstm_data_augmented.mat
clear; clc;

fprintf('========================================\n');
fprintf('  STEP 3: CSI Data Augmentation          \n');
fprintf('========================================\n\n');

%% Configuration
input_file = 'lstm_data_prepared.mat';
output_file = 'lstm_data_augmented.mat';

%% Load prepared dataset
fprintf('Step 1: Loading dataset from %s...\n', input_file);
if ~exist(input_file, 'file')
    error('File not found: %s\nRun step2_prepare_lstm_data.m first!', input_file);
end

load(input_file);
fprintf('  Loaded: %d train, %d val, %d test samples\n\n', ...
    length(Labels_Train), length(Labels_Val), length(Labels_Test));

%% Augmentation parameters - ADJUST FOR DIFFICULTY
fprintf('Step 2: Setting augmentation parameters...\n');

aug_params = struct();
aug_params.snr_db = 15;                    % Lower = harder (10=hard, 15=medium, 20=easy)
aug_params.phase_noise_std = 0.2;          % Higher = harder (0.1-0.3)
aug_params.amp_scale_range = [0.7, 1.3];   % Wider = harder
aug_params.time_warp_factor = 0.15;        % Higher = harder (0.1-0.3)
aug_params.subcarrier_dropout = 0.15;      % Higher = harder (0.1-0.3)
aug_params.apply_prob = 0.7;               % Probability per augmentation

fprintf('\nAugmentation Settings (MEDIUM difficulty):\n');
fprintf('  SNR: %d dB\n', aug_params.snr_db);
fprintf('  Phase noise: %.2f radians\n', aug_params.phase_noise_std);
fprintf('  Amplitude scale: [%.1f, %.1f]\n', aug_params.amp_scale_range);
fprintf('  Time warp factor: %.2f\n', aug_params.time_warp_factor);
fprintf('  Subcarrier dropout: %.0f%%\n', aug_params.subcarrier_dropout*100);
fprintf('  Apply probability: %.0f%% per augmentation\n\n', aug_params.apply_prob*100);

%% Apply augmentation
fprintf('Step 3: Applying augmentations...\n');

fprintf('Augmenting training data (%d samples)...\n', length(Labels_Train));
Data_Train_LSTM = augment_csi_data(Data_Train_LSTM, aug_params);

fprintf('Augmenting validation data (%d samples)...\n', length(Labels_Val));
Data_Val_LSTM = augment_csi_data(Data_Val_LSTM, aug_params);

fprintf('Augmenting test data (%d samples)...\n', length(Labels_Test));
Data_Test_LSTM = augment_csi_data(Data_Test_LSTM, aug_params);

%% Check class separability after augmentation
fprintf('\nStep 4: Checking class separability...\n');

sample_empty = Data_Train_LSTM{find(Labels_Train==1, 1)}(:);
sample_sit = Data_Train_LSTM{find(Labels_Train==2, 1)}(:);
sample_stand = Data_Train_LSTM{find(Labels_Train==3, 1)}(:);
sample_walk = Data_Train_LSTM{find(Labels_Train==4, 1)}(:);

dist_empty_sit = norm(abs(sample_empty) - abs(sample_sit));
dist_empty_stand = norm(abs(sample_empty) - abs(sample_stand));
dist_empty_walk = norm(abs(sample_empty) - abs(sample_walk));
dist_sit_stand = norm(abs(sample_sit) - abs(sample_stand));
dist_sit_walk = norm(abs(sample_sit) - abs(sample_walk));
dist_stand_walk = norm(abs(sample_stand) - abs(sample_walk));

fprintf('\nPairwise Euclidean Distances (augmented):\n');
fprintf('  EMPTY vs SIT:   %.2f\n', dist_empty_sit);
fprintf('  EMPTY vs STAND: %.2f\n', dist_empty_stand);
fprintf('  EMPTY vs WALK:  %.2f\n', dist_empty_walk);
fprintf('  SIT vs STAND:   %.2f\n', dist_sit_stand);
fprintf('  SIT vs WALK:    %.2f\n', dist_sit_walk);
fprintf('  STAND vs WALK:  %.2f\n', dist_stand_walk);

avg_dist = mean([dist_empty_sit, dist_empty_stand, dist_empty_walk, ...
                 dist_sit_stand, dist_sit_walk, dist_stand_walk]);
fprintf('\n  Average distance: %.2f\n', avg_dist);

if avg_dist < 40000
    fprintf('  Good! Distances reduced - dataset is now more challenging\n');
elseif avg_dist < 50000
    fprintf('  Moderate reduction - consider increasing augmentation strength\n');
else
    fprintf('  Distances still high - increase SNR noise or other augmentations\n');
end

%% Save augmented dataset
fprintf('\nStep 5: Saving augmented dataset to %s...\n', output_file);
save(output_file, ...
     'Data_Train_LSTM', 'Labels_Train', ...
     'Data_Val_LSTM', 'Labels_Val', ...
     'Data_Test_LSTM', 'Labels_Test', ...
     'activities', 'aug_params', ...
     '-v7.3');

fprintf('  Saved: %s\n', output_file);
fprintf('\nNext step: run step4_train_lstm.m\n');
