function [Data_FFT, freq_axis] = prepare_fft_features(Data_Time)
% Convert time-domain CSI to frequency-domain features
%
% Inputs:
%   Data_Time: Cell array of CSI samples [subcarriers x time_steps]
%
% Outputs:
%   Data_FFT: Cell array of FFT features [subcarriers x freq_bins]
%   freq_axis: Frequency axis for reference

    Data_FFT = cell(size(Data_Time));

    fprintf('Computing FFT features...\n');

    for i = 1:length(Data_Time)
        sample = Data_Time{i};  % [subcarriers x time_steps]

        % Take FFT along time dimension
        fft_result = fft(sample, [], 2);

        % Take magnitude spectrum (remove phase ambiguity)
        fft_mag = abs(fft_result);

        % Keep only positive frequencies (Nyquist)
        n_freq = floor(size(fft_mag, 2) / 2) + 1;
        fft_mag = fft_mag(:, 1:n_freq);

        % Log-scale (compress dynamic range)
        fft_mag = log10(fft_mag + 1e-10);

        Data_FFT{i} = fft_mag;

        if mod(i, 100) == 0
            fprintf('  Processed %d/%d samples\r', i, length(Data_Time));
        end
    end

    fprintf('\n  FFT features computed\n');

    % Create frequency axis (for reference)
    n_time = size(Data_Time{1}, 2);
    freq_axis = (0:n_freq-1) / n_time;  % Normalized frequency
end
