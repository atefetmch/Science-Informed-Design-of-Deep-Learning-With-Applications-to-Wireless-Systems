function [Prediction, net, accuracy] = LSTM_CSI_Classifier(...
    Data_Train, Labels_Train, Data_Val, Labels_Val, ...
    Data_Test, Labels_Test, output_dir)
% LSTM Classifier for CSI Activity Recognition
%
% Architecture: inputSize -> LSTM(128) -> LSTM(64) -> FC(4)
%
% Inputs:
%   Data_Train/Val/Test: Cell arrays of CSI [subcarriers x time_steps]
%   Labels_Train/Val/Test: Class labels (1-4)
%   output_dir: Directory for saving plots and results (default: 'lstm_results')
%
% Outputs:
%   Prediction: Test set predictions
%   net: Trained network
%   accuracy: Test accuracy (%)

%% Create output directory
if nargin < 7
    output_dir = 'lstm_results';
end
if ~exist(output_dir, 'dir')
    mkdir(output_dir);
end
fprintf('Plots will be saved to: %s/\n', output_dir);

%% Convert to magnitude only
if ~isreal(Data_Train{1})
    fprintf('Using magnitude only...\n');
    Data_Train = cellfun(@abs, Data_Train, 'UniformOutput', false);
    Data_Val = cellfun(@abs, Data_Val, 'UniformOutput', false);
    Data_Test = cellfun(@abs, Data_Test, 'UniformOutput', false);
end

%% Per-sample normalization (uses shared normalize_per_sample.m)
Data_Train = normalize_per_sample(Data_Train);
Data_Val = normalize_per_sample(Data_Val);
Data_Test = normalize_per_sample(Data_Test);

%% Network parameters
inputSize = size(Data_Train{1}, 1);  % 104 subcarriers
numHiddenUnits1 = 128;
numHiddenUnits2 = 64;
numClasses = 4;

fprintf('Architecture: %d -> %d -> %d -> %d\n', ...
    inputSize, numHiddenUnits1, numHiddenUnits2, numClasses);

%% Network
layers = [ ...
    sequenceInputLayer(inputSize)
    lstmLayer(numHiddenUnits1, 'OutputMode', 'sequence')
    dropoutLayer(0.3)
    lstmLayer(numHiddenUnits2, 'OutputMode', 'last')
    dropoutLayer(0.3)
    fullyConnectedLayer(numClasses)
    softmaxLayer
    classificationLayer];

%% Training options
options = trainingOptions('adam', ...
    'MaxEpochs', 20, ...
    'MiniBatchSize', 16, ...
    'InitialLearnRate', 0.001, ...
    'LearnRateSchedule', 'piecewise', ...
    'LearnRateDropFactor', 0.5, ...
    'LearnRateDropPeriod', 25, ...
    'SequenceLength', 'longest', ...
    'GradientThreshold', 1, ...
    'ValidationData', {Data_Val, categorical(Labels_Val)}, ...
    'ValidationFrequency', 10, ...
    'ExecutionEnvironment', 'auto', ...
    'Plots', 'training-progress', ...
    'Verbose', false, ...
    'OutputFcn', @(info) saveTrainingPlot(info, output_dir));

Labels_Train_cat = categorical(Labels_Train);

fprintf('\n=== Training LSTM ===\n');
net = trainNetwork(Data_Train, Labels_Train_cat, layers, options);

%% Save training plot (final state)
fig_training = findall(0, 'Type', 'figure', 'Name', 'Training Progress');
if ~isempty(fig_training)
    saveas(fig_training, fullfile(output_dir, 'training_progress.png'));
    saveas(fig_training, fullfile(output_dir, 'training_progress.fig'));
    fprintf('  Saved: training_progress.png/.fig\n');
end

%% Predict on test set
fprintf('\n=== Testing ===\n');
Prediction = classify(net, Data_Test, 'MiniBatchSize', 16, 'SequenceLength', 'longest');

Labels_Test_cat = categorical(Labels_Test);
accuracy = sum(Prediction == Labels_Test_cat) / length(Labels_Test_cat) * 100;

%% Save confusion matrix
fig_cm = figure('Visible', 'off');
cm = confusionchart(Labels_Test_cat, Prediction);
cm.Title = sprintf('Test Accuracy: %.2f%%', accuracy);
cm.RowSummary = 'row-normalized';
cm.ColumnSummary = 'column-normalized';

saveas(fig_cm, fullfile(output_dir, 'confusion_matrix.png'));
saveas(fig_cm, fullfile(output_dir, 'confusion_matrix.fig'));
fprintf('  Saved: confusion_matrix.png/.fig\n');
set(fig_cm, 'Visible', 'on');

%% Save network architecture
analyzeNetwork(net);
pause(2);
fig_analyzer = findall(0, 'Type', 'figure', 'Name', 'Network Analyzer');
if ~isempty(fig_analyzer)
    saveas(fig_analyzer(1), fullfile(output_dir, 'network_architecture.png'));
    saveas(fig_analyzer(1), fullfile(output_dir, 'network_architecture.fig'));
    fprintf('  Saved: network_architecture.png/.fig\n');
end

fprintf('\nTest Accuracy: %.2f%%\n', accuracy);
fprintf('All plots saved to: %s/\n', output_dir);

end

%% Helper: Save training plot periodically
function stop = saveTrainingPlot(info, output_dir)
    stop = false;
    if mod(info.Iteration, 10) == 0
        fig = findall(0, 'Type', 'figure', 'Name', 'Training Progress');
        if ~isempty(fig)
            filename = fullfile(output_dir, sprintf('training_epoch_%d.png', info.Iteration));
            saveas(fig, filename);
        end
    end
end
