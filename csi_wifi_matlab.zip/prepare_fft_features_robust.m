function [Data_FFT, freq_axis] = prepare_fft_features_robust(Data_Time)
% Robust FFT features using only LOW frequencies
% High frequencies contain mostly noise and are domain-specific
%
% Inputs:
%   Data_Time: Cell array of CSI samples [subcarriers x time_steps]
%
% Outputs:
%   Data_FFT: Cell array of FFT features [subcarriers x n_time_target]
%   freq_axis: Frequency axis for reference

    Data_FFT = cell(size(Data_Time));

    fprintf('Computing ROBUST low-frequency FFT features...\n');

    % Configuration
    freq_keep_ratio = 0.15;       % Keep only 15% lowest frequencies
    use_interpolation = true;

    n_time_target = size(Data_Time{1}, 2);

    for i = 1:length(Data_Time)
        sample = Data_Time{i};  % [subcarriers x time_steps]

        % Take FFT along time dimension
        fft_result = fft(sample, [], 2);

        % Take magnitude spectrum (phase-invariant)
        fft_mag = abs(fft_result);

        % Keep only positive frequencies (Nyquist)
        n_freq_total = floor(size(fft_mag, 2) / 2) + 1;
        fft_mag_half = fft_mag(:, 1:n_freq_total);

        % KEEP ONLY LOW FREQUENCIES (robust band)
        n_freq_keep = max(5, floor(n_freq_total * freq_keep_ratio));
        fft_low = fft_mag_half(:, 1:n_freq_keep);

        % Apply log-scale BEFORE interpolation (better numerics)
        fft_low = log10(fft_low + 1e-10);

        if use_interpolation
            % Interpolate to match time domain length
            n_sub = size(fft_low, 1);
            fft_interp = zeros(n_sub, n_time_target);

            for sub = 1:n_sub
                fft_interp(sub, :) = interp1(1:n_freq_keep, fft_low(sub, :), ...
                    linspace(1, n_freq_keep, n_time_target), 'pchip');
            end

            Data_FFT{i} = fft_interp;
        else
            % Pad with last value (better than zeros)
            n_sub = size(fft_low, 1);
            if n_freq_keep < n_time_target
                last_val = fft_low(:, end);
                padding = repmat(last_val, 1, n_time_target - n_freq_keep);
                Data_FFT{i} = [fft_low, padding];
            else
                Data_FFT{i} = fft_low(:, 1:n_time_target);
            end
        end

        if mod(i, 100) == 0
            fprintf('  Processed %d/%d samples\r', i, length(Data_Time));
        end
    end

    fprintf('\n  Robust FFT features computed\n');
    fprintf('  Using %.0f%% of frequency spectrum (%d bins)\n', ...
        freq_keep_ratio*100, n_freq_keep);

    freq_axis = linspace(0, 0.5*freq_keep_ratio, n_time_target);
end
