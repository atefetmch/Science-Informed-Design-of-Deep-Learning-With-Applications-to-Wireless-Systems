function [Prediction, net, accuracy] = LSTM_CSI_Classifier_DualPath(...
    Data_Train_Time, Data_Train_Freq, Labels_Train, ...
    Data_Val_Time, Data_Val_Freq, Labels_Val, ...
    Data_Test_Time, Data_Test_Freq, Labels_Test, ...
    output_dir)
% Dual-Path LSTM: Time + Frequency Domains
%
% Concatenates time-domain and frequency-domain features into a single
% input vector, then trains a standard LSTM classifier.
%
% Inputs:
%   Data_*_Time: Cell arrays of time-domain CSI [n_sub x n_time]
%   Data_*_Freq: Cell arrays of freq-domain features [n_sub x n_freq]
%   Labels_*: Class labels (1-4)
%   output_dir: Directory for saving plots (default: 'lstm_results_dualpath')
%
% Outputs:
%   Prediction: Test set predictions
%   net: Trained network
%   accuracy: Test accuracy (%)

if nargin < 10
    output_dir = 'lstm_results_dualpath';
end
if ~exist(output_dir, 'dir')
    mkdir(output_dir);
end
fprintf('Dual-Path LSTM with Time + Frequency domains\n');
fprintf('Plots will be saved to: %s/\n', output_dir);

%% Convert to magnitude only
if ~isreal(Data_Train_Time{1})
    fprintf('Converting to magnitude...\n');
    Data_Train_Time = cellfun(@abs, Data_Train_Time, 'UniformOutput', false);
    Data_Val_Time = cellfun(@abs, Data_Val_Time, 'UniformOutput', false);
    Data_Test_Time = cellfun(@abs, Data_Test_Time, 'UniformOutput', false);
    Data_Train_Freq = cellfun(@abs, Data_Train_Freq, 'UniformOutput', false);
    Data_Val_Freq = cellfun(@abs, Data_Val_Freq, 'UniformOutput', false);
    Data_Test_Freq = cellfun(@abs, Data_Test_Freq, 'UniformOutput', false);
end

%% Per-sample normalization (uses shared normalize_per_sample.m)
fprintf('Normalizing time-domain data...\n');
Data_Train_Time = normalize_per_sample(Data_Train_Time);
Data_Val_Time = normalize_per_sample(Data_Val_Time);
Data_Test_Time = normalize_per_sample(Data_Test_Time);

fprintf('Normalizing frequency-domain data...\n');
Data_Train_Freq = normalize_per_sample(Data_Train_Freq);
Data_Val_Freq = normalize_per_sample(Data_Val_Freq);
Data_Test_Freq = normalize_per_sample(Data_Test_Freq);

%% Check and display dimensions
fprintf('\nDimension Check:\n');
fprintf('  Time domain:      [%d x %d]\n', size(Data_Train_Time{1}));
fprintf('  Frequency domain: [%d x %d]\n', size(Data_Train_Freq{1}));

%% Concatenate time + frequency features (uses shared concatenate_features.m)
fprintf('\nConcatenating time and frequency features (with padding)...\n');
Data_Train = concatenate_features(Data_Train_Time, Data_Train_Freq);
Data_Val = concatenate_features(Data_Val_Time, Data_Val_Freq);
Data_Test = concatenate_features(Data_Test_Time, Data_Test_Freq);

fprintf('  Combined features: [%d x %d]\n', size(Data_Train{1}));
fprintf('  (First %d rows = time, next %d rows = frequency)\n\n', ...
    size(Data_Train_Time{1}, 1), size(Data_Train_Freq{1}, 1));

%% Network parameters
inputSize = size(Data_Train{1}, 1);
numHiddenUnits1 = 128;
numHiddenUnits2 = 64;
numClasses = 4;

fprintf('Architecture: %d -> %d -> %d -> %d\n', ...
    inputSize, numHiddenUnits1, numHiddenUnits2, numClasses);
fprintf('  (Input = Time features + Frequency features)\n\n');

%% Network layers
layers = [ ...
    sequenceInputLayer(inputSize)
    lstmLayer(numHiddenUnits1, 'OutputMode', 'sequence')
    dropoutLayer(0.3)
    lstmLayer(numHiddenUnits2, 'OutputMode', 'last')
    dropoutLayer(0.3)
    fullyConnectedLayer(numClasses)
    softmaxLayer
    classificationLayer];

%% Training options
options = trainingOptions('adam', ...
    'MaxEpochs', 30, ...
    'MiniBatchSize', 16, ...
    'InitialLearnRate', 0.001, ...
    'LearnRateSchedule', 'piecewise', ...
    'LearnRateDropFactor', 0.5, ...
    'LearnRateDropPeriod', 25, ...
    'SequenceLength', 'longest', ...
    'GradientThreshold', 1, ...
    'ValidationData', {Data_Val, categorical(Labels_Val)}, ...
    'ValidationFrequency', 10, ...
    'ExecutionEnvironment', 'auto', ...
    'Plots', 'training-progress', ...
    'Verbose', false, ...
    'OutputFcn', @(info) saveTrainingPlot(info, output_dir));

Labels_Train_cat = categorical(Labels_Train);

fprintf('=== Training Dual-Path LSTM ===\n');
net = trainNetwork(Data_Train, Labels_Train_cat, layers, options);

%% Save training plot
fig_training = findall(0, 'Type', 'figure', 'Name', 'Training Progress');
if ~isempty(fig_training)
    saveas(fig_training, fullfile(output_dir, 'training_progress.png'));
    saveas(fig_training, fullfile(output_dir, 'training_progress.fig'));
    fprintf('  Saved: training_progress.png\n');
end

%% Predict on test set
fprintf('\n=== Testing ===\n');
Prediction = classify(net, Data_Test, 'MiniBatchSize', 16, 'SequenceLength', 'longest');

Labels_Test_cat = categorical(Labels_Test);
accuracy = sum(Prediction == Labels_Test_cat) / length(Labels_Test_cat) * 100;

%% Save confusion matrix
fig_cm = figure('Visible', 'off');
cm = confusionchart(Labels_Test_cat, Prediction);
cm.Title = sprintf('Dual-Path LSTM (Time+Freq) - Accuracy: %.2f%%', accuracy);
cm.RowSummary = 'row-normalized';
cm.ColumnSummary = 'column-normalized';

saveas(fig_cm, fullfile(output_dir, 'confusion_matrix.png'));
saveas(fig_cm, fullfile(output_dir, 'confusion_matrix.fig'));
fprintf('  Saved: confusion_matrix.png\n');
set(fig_cm, 'Visible', 'on');

fprintf('\nTest Accuracy: %.2f%%\n', accuracy);
fprintf('All plots saved to: %s/\n', output_dir);

end

%% Helper: Save training plot periodically
function stop = saveTrainingPlot(info, output_dir)
    stop = false;
    if mod(info.Iteration, 10) == 0
        fig = findall(0, 'Type', 'figure', 'Name', 'Training Progress');
        if ~isempty(fig)
            filename = fullfile(output_dir, sprintf('training_epoch_%d.png', info.Iteration));
            saveas(fig, filename);
        end
    end
end
