function data_aug = augment_csi_data(data, aug_params)
% Augment CSI data to increase difficulty and realism
%
% Inputs:
%   data: Cell array of CSI samples [subcarriers x time_steps]
%   aug_params: Structure with augmentation parameters
%
% Outputs:
%   data_aug: Augmented cell array
%
% aug_params fields:
%   - snr_db: Signal-to-noise ratio in dB (lower = harder, e.g., 10-20 dB)
%   - phase_noise_std: Phase noise std (radians, e.g., 0.1-0.3)
%   - amp_scale_range: Amplitude scaling [min, max] (e.g., [0.7, 1.3])
%   - time_warp_factor: Time warping strength (e.g., 0.1-0.2)
%   - subcarrier_dropout: Fraction of subcarriers to drop (e.g., 0.1-0.2)
%   - apply_prob: Probability of applying each augmentation (e.g., 0.5)

    data_aug = cell(size(data));

    for i = 1:length(data)
        sample = data{i};  % [subcarriers x time_steps]

        % 1. SNR-based Gaussian noise (realistic wireless noise)
        if rand < aug_params.apply_prob
            signal_power = mean(abs(sample(:)).^2);
            noise_power = signal_power / (10^(aug_params.snr_db/10));
            noise = sqrt(noise_power/2) * (randn(size(sample)) + 1j*randn(size(sample)));
            sample = sample + noise;
        end

        % 2. Phase noise (oscillator imperfections)
        if rand < aug_params.apply_prob
            phase_noise = aug_params.phase_noise_std * randn(size(sample));
            sample = abs(sample) .* exp(1j*(angle(sample) + phase_noise));
        end

        % 3. Amplitude scaling (distance/position variation)
        if rand < aug_params.apply_prob
            scale = aug_params.amp_scale_range(1) + ...
                    (aug_params.amp_scale_range(2) - aug_params.amp_scale_range(1)) * rand;
            sample = sample * scale;
        end

        % 4. Time warping (activity speed variation)
        if rand < aug_params.apply_prob
            sample = time_warp(sample, aug_params.time_warp_factor);
        end

        % 5. Subcarrier dropout (antenna/hardware issues)
        if rand < aug_params.apply_prob
            n_drop = round(size(sample, 1) * aug_params.subcarrier_dropout);
            if n_drop > 0
                drop_idx = randperm(size(sample, 1), n_drop);
                sample(drop_idx, :) = 0;
            end
        end

        % 6. Frequency-selective fading (multipath effects)
        if rand < aug_params.apply_prob
            fading = 0.8 + 0.4*rand(size(sample, 1), 1);
            sample = sample .* fading;
        end

        data_aug{i} = sample;

        if mod(i, 100) == 0
            fprintf('  Processed %d/%d samples\r', i, length(data));
        end
    end
    fprintf('\n');
end

function warped = time_warp(signal, strength)
    % Time warping for temporal variation (activity speed changes)
    [n_sub, n_time] = size(signal);

    warp_points = 5;
    ctrl_warp = 1 + strength * (2*rand(1, warp_points) - 1);
    warp_curve = interp1(linspace(1, n_time, warp_points), ctrl_warp, 1:n_time, 'pchip');

    new_indices = cumsum(warp_curve);
    new_indices = (new_indices - min(new_indices)) / ...
                  (max(new_indices) - min(new_indices)) * (n_time - 1) + 1;

    warped = zeros(size(signal));
    for i = 1:n_sub
        warped(i, :) = interp1(1:n_time, signal(i, :), new_indices, 'linear', 'extrap');
    end
end
