# CSI WiFi Activity Recognition - MATLAB Code

LSTM-based human activity recognition using Channel State Information (CSI)
from WiFi signals, with domain shift analysis and dual-path (time + frequency)
architecture.

## Pipeline

```
Step 1: Load CSI from PCAP         --> csi_raw_data.mat
Step 2: Prepare & Split (70/15/15) --> lstm_data_prepared.mat
Step 3: Augment Dataset             --> lstm_data_augmented.mat
Step 4: Train Baseline LSTM         --> lstm_results/trained_model.mat
Step 5: Create Target Domain        --> lstm_data_target_domain.mat
Step 6: Test on Target Domain       --> lstm_results_target_domain/
Step 7: Train Dual-Path LSTM        --> lstm_results_dualpath/
Step 8: Test Dual-Path on Target    --> lstm_results_dualpath_target/
```

## Quick Start

```matlab
% Run each step in order:
step1_load_csi_data            % Requires CSIReader() and PCAP files
step2_prepare_lstm_data        % Stratified train/val/test split
step3_create_augmented_dataset % Apply channel augmentations
step4_train_lstm               % Train baseline LSTM (104->128->64->4)
step5_create_target_domain     % Create shifted test set
step6_test_on_target_domain    % Evaluate baseline under domain shift
step7_train_dualpath           % Train time+frequency dual-path LSTM
step8_test_dualpath_on_target  % Evaluate dual-path under domain shift
```

## Files

### Pipeline Scripts (run in order)
| File | Description |
|------|-------------|
| `step1_load_csi_data.m` | Load CSI data from PCAP files |
| `step2_prepare_lstm_data.m` | Stratified split and LSTM formatting |
| `step3_create_augmented_dataset.m` | Apply augmentations |
| `step4_train_lstm.m` | Train and evaluate baseline LSTM |
| `step5_create_target_domain.m` | Create target domain test set |
| `step6_test_on_target_domain.m` | Evaluate under domain shift |
| `step7_train_dualpath.m` | Train dual-path (time+freq) LSTM |
| `step8_test_dualpath_on_target.m` | Evaluate dual-path under shift |

### Functions
| File | Description |
|------|-------------|
| `LSTM_CSI_Classifier.m` | Baseline LSTM classifier |
| `LSTM_CSI_Classifier_DualPath.m` | Dual-path LSTM classifier |
| `augment_csi_data.m` | CSI augmentation (SNR, phase, time warp, etc.) |
| `prepare_fft_features.m` | Full FFT features |
| `prepare_fft_features_robust.m` | Low-frequency robust FFT features |
| `normalize_per_sample.m` | Per-sample normalization (shared) |
| `concatenate_features.m` | Time+frequency feature concatenation (shared) |

## Data Format

- **CSI shape**: `[subcarriers x time_steps]` = `[104 x 150]` (MATLAB LSTM format)
- **Labels**: 1=EMPTY, 2=SIT, 3=STAND, 4=WALK
- **Normalization**: Per-sample (mean=0, std=1)

## Requirements

- MATLAB R2020b+ with Deep Learning Toolbox
- `CSIReader()` function for PCAP parsing (step 1 only)
