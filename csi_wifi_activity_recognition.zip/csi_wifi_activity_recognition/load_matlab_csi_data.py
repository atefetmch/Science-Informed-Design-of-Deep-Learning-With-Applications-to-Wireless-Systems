"""
Load CSI Data from Existing MATLAB .mat File

Loads the csi_raw_data_large.mat file created by step1_load_csi_data_new.m,
converts MATLAB cell arrays to Python lists, and saves as pickle for fast
future loading.
"""

import numpy as np
import scipy.io as sio
import pickle
from pathlib import Path
from typing import Dict, List


def load_csi_from_matlab(mat_file: str = 'csi_raw_data_large.mat') -> Dict:
    """
    Load CSI data from MATLAB .mat file.

    Args:
        mat_file: Path to the .mat file created by MATLAB.

    Returns:
        data_dict: Dictionary containing:
            - 'csi_data': List of numpy arrays (each: 150x104 complex)
            - 'labels': numpy array of labels (0-3)
            - 'filenames': List of filenames
            - 'activities': List of activity names
            - 'num_samples': Total number of samples
    """
    print(f"Loading CSI data from {mat_file}...")

    mat_data = sio.loadmat(mat_file)

    all_csi_data_matlab = mat_data['all_csi_data']
    all_labels = mat_data['all_labels'].flatten()
    all_filenames_matlab = mat_data['all_filenames']
    activities_matlab = mat_data['activities']

    print(f"  Loaded {len(all_labels)} samples")

    # Convert MATLAB cell arrays to Python lists
    print("  Converting MATLAB cell arrays to Python format...")

    csi_data = []
    for i in range(len(all_csi_data_matlab)):
        csi_matrix = all_csi_data_matlab[i, 0]
        csi_data.append(csi_matrix)

    filenames = []
    for i in range(len(all_filenames_matlab)):
        filename = all_filenames_matlab[i, 0][0]
        filenames.append(filename)

    activities = []
    for i in range(len(activities_matlab[0])):
        activity = activities_matlab[0, i][0]
        activities.append(activity)

    # MATLAB labels are 1-indexed, convert to 0-indexed
    labels = all_labels - 1

    print("  Conversion complete")

    data_dict = {
        'csi_data': csi_data,
        'labels': labels.astype(np.int64),
        'filenames': filenames,
        'activities': activities,
        'num_samples': len(labels)
    }

    return data_dict


def verify_data(data_dict: Dict):
    """Verify the loaded CSI data."""
    print("\n" + "=" * 70)
    print("DATA VERIFICATION")
    print("=" * 70)

    num_samples = data_dict['num_samples']
    print(f"\nTotal samples: {num_samples}")
    print(f"Activities: {data_dict['activities']}")

    first_sample = data_dict['csi_data'][0]
    print(f"\nFirst sample:")
    print(f"  Shape: {first_sample.shape}")
    print(f"  Data type: {first_sample.dtype}")
    print(f"  Is complex: {np.iscomplexobj(first_sample)}")
    print(f"  Min value: {np.min(np.abs(first_sample)):.4f}")
    print(f"  Max value: {np.max(np.abs(first_sample)):.4f}")
    print(f"  Mean value: {np.mean(np.abs(first_sample)):.4f}")

    # Class distribution
    print("\nClass Distribution:")
    print("-" * 50)
    labels = data_dict['labels']
    activities = data_dict['activities']

    for i, activity in enumerate(activities):
        count = np.sum(labels == i)
        percentage = 100 * count / num_samples
        print(f"  {activity:8s} (label {i}): {count:4d} samples ({percentage:5.1f}%)")

    # Dimension check
    print("\nDimension Check:")
    print("-" * 50)
    expected_shape = (150, 104)
    correct_count = 0
    incorrect_samples = []

    for i, sample in enumerate(data_dict['csi_data']):
        if sample.shape == expected_shape:
            correct_count += 1
        else:
            incorrect_samples.append((i, sample.shape))

    print(f"  Samples with correct shape {expected_shape}: {correct_count}/{num_samples}")

    if incorrect_samples:
        print(f"  WARNING: {len(incorrect_samples)} samples have incorrect dimensions:")
        for idx, shape in incorrect_samples[:5]:
            print(f"    Sample {idx}: {shape}")
    else:
        print(f"  All samples have correct dimensions!")

    # Memory estimate
    sample_size_bytes = first_sample.nbytes
    total_memory_mb = (num_samples * sample_size_bytes) / (1024 ** 2)
    print(f"\nMemory Usage:")
    print(f"  Per sample: ~{sample_size_bytes / 1024:.2f} KB")
    print(f"  Total: ~{total_memory_mb:.2f} MB")

    print("=" * 70 + "\n")


def save_to_pickle(data_dict: Dict, output_file: str = 'csi_data_python.pkl'):
    """Save loaded data to pickle for fast future loading."""
    print(f"Saving to pickle: {output_file}...")

    with open(output_file, 'wb') as f:
        pickle.dump(data_dict, f, protocol=pickle.HIGHEST_PROTOCOL)

    file_size_mb = Path(output_file).stat().st_size / (1024 ** 2)
    print(f"  Saved: {output_file} ({file_size_mb:.2f} MB)")
    print(f"\nNext time, load instantly with:")
    print(f"  data = load_from_pickle('{output_file}')")


def load_from_pickle(pickle_file: str = 'csi_data_python.pkl') -> Dict:
    """Quick load from previously saved pickle file."""
    print(f"Loading from pickle: {pickle_file}...")

    with open(pickle_file, 'rb') as f:
        data_dict = pickle.load(f)

    print(f"  Loaded {data_dict['num_samples']} samples")
    return data_dict


def get_sample_by_index(data_dict: Dict, index: int):
    """Get a specific sample by index."""
    csi_matrix = data_dict['csi_data'][index]
    label = data_dict['labels'][index]
    activity = data_dict['activities'][label]
    filename = data_dict['filenames'][index]

    print(f"\nSample {index}:")
    print(f"  Filename: {filename}")
    print(f"  Activity: {activity} (label={label})")
    print(f"  Shape: {csi_matrix.shape}")
    print(f"  Type: {csi_matrix.dtype}")

    return csi_matrix, label, activity, filename


def get_samples_by_activity(data_dict: Dict, activity: str) -> Dict:
    """Get all samples for a specific activity."""
    activity_idx = data_dict['activities'].index(activity)
    mask = data_dict['labels'] == activity_idx

    activity_data = {
        'csi_data': [data_dict['csi_data'][i] for i in range(len(mask)) if mask[i]],
        'labels': data_dict['labels'][mask],
        'filenames': [data_dict['filenames'][i] for i in range(len(mask)) if mask[i]],
        'activity': activity,
        'num_samples': np.sum(mask)
    }

    print(f"Extracted {activity_data['num_samples']} samples for '{activity}'")
    return activity_data


def main():
    """Main execution."""
    print("=" * 70)
    print("CSI DATA LOADER - From MATLAB .mat File")
    print("=" * 70 + "\n")

    mat_file = 'csi_raw_data_large.mat'
    data_dict = load_csi_from_matlab(mat_file)
    verify_data(data_dict)
    save_to_pickle(data_dict, 'csi_data_python.pkl')

    print("\nExample: Accessing sample data")
    print("-" * 70)
    get_sample_by_index(data_dict, 0)

    print("\n" + "-" * 70)
    get_samples_by_activity(data_dict, 'SIT')

    print("\n" + "=" * 70)
    print("COMPLETE - Data is ready for PyTorch LSTM training!")
    print("=" * 70 + "\n")

    return data_dict


if __name__ == '__main__':
    data = main()
